package com.brtbeacon.map3d.demo.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.widget.ArrayAdapter;

public class FloorMenuAdapter extends ArrayAdapter {

    public FloorMenuAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }



}
