package com.brtbeacon.map3d.demo.map.basic;

import android.os.Bundle;

import com.brtbeacon.map3d.demo.activity.BaseMapActivity;

public class SimpleMapActivity extends BaseMapActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

}
