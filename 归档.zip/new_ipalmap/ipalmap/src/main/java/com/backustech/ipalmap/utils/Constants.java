package com.backustech.ipalmap.utils;

/**
 * Created by jian.feng on 2017/6/1.
 */

public interface Constants {
    String BUILD_ID = "02KE01";
    String APP_ID="444dbbb040";
    String APP_KEY="b7bb83a0b873437294164820e550986f";
    String SERVER_BACK_URL="https://huitu.zhishulib.com";
    String BOOK_URL="/Bookshelf/Bookshelf/findBookIndex";
    String BOOK_REPORT_MISS_URL="/Bookshelf/Bookshelf/reportMissing";
}
